<div class="info">
    <div class="info-content">
        <h2 class="title animate fadeIn" data-wow-delay="0.2s">I'm Andrea, and this is a title</h2>
        <h3 class="subtitle animate fadeIn" data-wow-delay="0.4s">It's complicated to write so much dummy content, you know.</h3>
        <p class="resume animate fadeIn" data-wow-delay="0.6s">Et harum quidem rerum facilis est et expedita distinctio. Quia consequuntur magni dolores eos 
         qui ratione voluptatem sequi nesciunt. Do eiusmod tempor incididunt ut labore.</p>
        <a href="/2018/08/31/hola-mundo/" class="button animate fadeIn" data-wow-delay="0.8s">Meet Andrea, the Avant Garde Theme.</a>
    </div>
</div>