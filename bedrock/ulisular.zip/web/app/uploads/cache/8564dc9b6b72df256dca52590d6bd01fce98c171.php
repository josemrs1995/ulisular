
<div class="fondo" style="background:url('<?php echo e(App::thumbnail()); ?>'); background-position: center center; background-size: cover; background-repeat: no-repeat;">
    <div class="page-header">
        <div class="contenido-page-header">
          <h5 class="page-header-h5"><?php echo App::title(); ?></h5>
          <p class="page-header-p"><?php echo e(get_field('descripcion_header', 'option')); ?></p>
        </div>
        <img class="svg-interno" src="<?= App\asset_path('images/svg/vector-3-01.svg'); ?>" style="width:100%; height:auto; " >
        </div>
</div>